namespace Furnitures
{
	public class Bed 
	{ 
	} 
}
