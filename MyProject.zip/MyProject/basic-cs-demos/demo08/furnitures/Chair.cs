namespace Furnitures
{
	public class Chair 
	{ 
	} 
}
