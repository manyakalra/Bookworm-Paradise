namespace Utils
{
	public class Input 
	{ 
	} 
}
