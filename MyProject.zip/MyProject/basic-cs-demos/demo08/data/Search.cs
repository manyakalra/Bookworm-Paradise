namespace Data
{
	public class Search 
	{ 
	} 
}
