namespace Concept.Data
{
	public class Table 
	{ 
		public int rows=5;
		public int columns=3;
	} 
}
