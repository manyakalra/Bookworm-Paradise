namespace Concept.Data
{
	public class Search 
	{ 
	} 
}
