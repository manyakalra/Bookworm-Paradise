namespace Concept.Furnitures
{
	public class Table 
	{ 
		public int price=5000;

		public Table(int p)
		{
			price=p;
		}

	} 
}
