namespace Concept.Furnitures
{
	public class Bed 
	{ 
	} 
}
