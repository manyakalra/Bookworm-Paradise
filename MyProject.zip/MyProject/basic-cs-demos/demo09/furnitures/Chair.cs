namespace Concept.Furnitures
{
	public class Chair 
	{ 
	} 
}
