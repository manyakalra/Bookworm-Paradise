public class Bed 
{ 
} 
