public class Chair 
{ 
} 
