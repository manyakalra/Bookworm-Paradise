﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccountTests
{
    public  class Math
    {
        public static int Plus(int x,int y)  {  return x + y;    }
        public static int Minus(int x, int y) { return x - y; }
        public static int Multiply(int x, int y) { return x * y; }
        public static int Divide(int x, int y) { return x / y; }
    }
}
