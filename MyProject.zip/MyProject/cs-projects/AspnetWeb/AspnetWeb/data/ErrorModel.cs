﻿namespace AspnetWeb.data
{
    public class ErrorModel
    {
        public string Title { get; set; }
        public string Message { get; set; }
    }
}
