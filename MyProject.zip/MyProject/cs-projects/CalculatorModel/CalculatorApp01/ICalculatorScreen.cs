﻿namespace ConceptArchitect.Calculators
{
    public interface ICalculatorScreen
    {
        void Show(object output);
    }
}