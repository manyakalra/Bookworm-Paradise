﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConceptArchitect.BookManagement
{
    public enum BookFormat
    {
        paperback,
        ebook,
        audiobook,
        hardbound
    }
    public class BookVariantInfo
    {
        public string Id { get; set; }
        public string Isbn { get; set; }

        public string Title { get; set; }

        public string Cover { get; set; }

        public BookFormat Format { get; set; }

        public int Price { get; set; }

        public string PublisherId { get; set; }

    }



}
