﻿
--create table authors
--(
--	id varchar(50) primary key
--);

drop table if exists authors;