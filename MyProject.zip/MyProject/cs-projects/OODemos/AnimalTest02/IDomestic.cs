﻿namespace AnimalTests
{
    internal interface IDomestic
    {
    }
}