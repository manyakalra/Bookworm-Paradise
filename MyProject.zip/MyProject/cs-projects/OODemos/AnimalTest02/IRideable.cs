﻿namespace AnimalTests
{
    internal interface IRideable
    {
        string Ride();
    }
}