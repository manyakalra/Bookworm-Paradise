﻿using ConceptArchitect.Shapes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EcoLabsShapeProject
{
    public class Elipse : Shape
    {
        public override double Area
        {
            get
            {
                return 0;
            }
        }

        public override double Perimeter
        {
            get
            {
                return 0;
            }
        }
    }
}
