﻿using ConceptArchitect.Shapes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeTest2
{
    internal class Program
    {
        public static void Main()
        {
            var p = new Point3D(3,4,5);

        }
    }
}
